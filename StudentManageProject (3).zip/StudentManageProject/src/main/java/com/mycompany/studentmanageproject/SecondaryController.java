package com.mycompany.studentmanageproject;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class SecondaryController {

    @FXML

    Label reslbl;

    @FXML
    private void AddStudent(ActionEvent event) throws IOException {
         reslbl.setText("Opening Add Student Page...");
        App.setRoot("Assign");
    }

    @FXML
    private void ShowStudent(ActionEvent event) throws IOException {
         reslbl.setText("Opening Show Student Page...");
        App.setRoot("Show");
    }

    @FXML
    private void AddGrade(ActionEvent event) throws IOException {
          reslbl.setText("Opening Add Grade Page...");
        App.setRoot("AddGrade");
    }

     @FXML
    private void SaveToFile(ActionEvent event) throws IOException {
        try {
            File f = new File("data.bin");
            f.delete();
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("data.bin"));
            oos.writeObject(App.allStudents);
            reslbl.setText("Successfully saved " + App.allStudents.size() + " students to file");
            oos.close();
        } catch (IOException e) {
            reslbl.setText("Error saving to file: " + e.getMessage());

        }
    }

    @FXML
    private void ReadFromFile() throws IOException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("data.bin"))) {
            App.allStudents.clear();
            App.allStudents = (ArrayList<Student>) ois.readObject();
            reslbl.setText("Successfully loaded " + App.allStudents.size() + " students from file");
        } catch (IOException | ClassNotFoundException e) {
            reslbl.setText("Error loading from file: " + e.getMessage());
        }
    }
     @FXML
    private void Report(ActionEvent event) throws IOException {
            reslbl.setText("Generating Report...");
        App.setRoot("Report");
    }
}