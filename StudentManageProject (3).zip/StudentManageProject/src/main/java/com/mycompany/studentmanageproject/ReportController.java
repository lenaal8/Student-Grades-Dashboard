/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.studentmanageproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author sara
 */
public class ReportController implements Initializable {

    @FXML
    Label reslbl;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        if (App.allStudents.size() > 0) {
            double total = 0, avarage = 0;
            int countpass = 0, countfail = 0, countaboveavg = 0, counbelowavg = 0;

            for (Student s : App.allStudents) {
                total = total + s.getScore();

            }
            avarage = total / App.allStudents.size();

            for (Student s : App.allStudents) {
                if (s.getScore() > 60) {
                    countpass++;
                } else {
                    countfail++;
                }
                if (s.getScore() > avarage) {
                    countaboveavg++;
                } else {
                    counbelowavg++;
                }

            }
            reslbl.setText("Total Number Of students  is :" + App.allStudents.size()
                    + "\nAvarage Score :" + avarage
                    + "\nNumber of Passing Students :" + countpass
                    + "\nNumber of Failing Students :" + countfail
                    + "\nNumber of Above Avarage Students :" + countaboveavg
                    + "\nNumber of Below Avarage Students :" + counbelowavg 
            );

        }
    }

    @FXML
    private void Back() throws IOException {
        App.setRoot("secondary");
    }

}
