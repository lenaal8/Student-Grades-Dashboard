package com.mycompany.studentmanageproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

public class PrimaryController implements Initializable {

    @FXML
    TextField PassTxt;
    @FXML
    TextField userNametxt;
    @FXML
    Label resultlbl;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void switchToSecondary() throws IOException {
        
        if (PassTxt.getText().equals(App.password) && userNametxt.getText().equals(App.username)) {
            App.setRoot("secondary");
        } else {
            resultlbl.setText("User name or password are not correct");
        }
    }
}
