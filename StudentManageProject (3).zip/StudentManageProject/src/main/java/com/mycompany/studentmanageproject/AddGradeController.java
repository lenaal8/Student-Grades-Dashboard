/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentmanageproject;

/**
 *
 * @author lena8
 */

    
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

/**
 * FXML Controller class
 *
 * @author yusra
 */
public class AddGradeController implements Initializable {

    @FXML
    ComboBox StudentIDs;
    @FXML

    TextField gradetxt;
    @FXML
    Label reslbl;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        StudentIDs.getItems().clear();
        if (App.allStudents.size() == 0) {
            reslbl.setText("No student please add a students first");
        }
        for (Student s : App.allStudents) {
            StudentIDs.getItems().add(s.ID);

        }
        StudentIDs.getSelectionModel().select(0);
    }

    @FXML
    private void ADDGrade() throws IOException {
        if (App.allStudents.size() > 0) {
            if (gradetxt.getText().isEmpty()) {
                reslbl.setText("all Data Required");
            } else {

                int id = (int) StudentIDs.getSelectionModel().getSelectedItem();
                for (Student s : App.allStudents) {
                    if(s.getID()==id)
                        s.setScore(Double.parseDouble(gradetxt.getText()));
                }
            }
        }
    }

    @FXML
    private void Back() throws IOException {
        App.setRoot("secondary");
    }
}

    

