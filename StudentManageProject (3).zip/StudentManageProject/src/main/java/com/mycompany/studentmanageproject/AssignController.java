/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.studentmanageproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

/**
 * FXML Controller class
 *
 * @author SaraN
 */
public class AssignController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    TextField idtxt;
    @FXML
    Label result;
    @FXML
    TextField nametxt; 
    @FXML
    TextField majortxt;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
   
private void AddStudent() throws IOException {

    if(idtxt.getText().isEmpty() ||
       nametxt.getText().isEmpty() ||
       majortxt.getText().isEmpty()) {

        result.setText("All data required");

    } else {

        int ID = Integer.parseInt(idtxt.getText());
        String name = nametxt.getText();
        String major = majortxt.getText();

        Student s = new Student(name, ID, major);

        App.allStudents.add(s);

        result.setText("Student added successfully");
        nametxt.clear();
        majortxt.clear();
        idtxt.clear();
    }
}    
@FXML
    private void Back() throws IOException {
        App.setRoot("secondary");
    }
}