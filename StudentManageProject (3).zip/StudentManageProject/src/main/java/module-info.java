module com.mycompany.studentmanageproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.studentmanageproject to javafx.fxml;
    exports com.mycompany.studentmanageproject;
}
